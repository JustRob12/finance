window.env = {
  VITE_API_URL: 'http://Finance-app-env.eba-63qkf9zb.us-east-1.elasticbeanstalk.com',
}; 
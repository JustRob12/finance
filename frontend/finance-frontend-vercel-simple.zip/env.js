window.env = {
  VITE_API_URL: '/api',
}; 